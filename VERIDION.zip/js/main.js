// Veridion LLP — site interactions (mobile nav + booking modal)
document.addEventListener("DOMContentLoaded", function () {
  // Mobile nav toggle
  var toggle = document.querySelector(".nav-toggle");
  var links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", function () {
      links.classList.toggle("is-open");
    });
    links.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () { links.classList.remove("is-open"); });
    });
  }

  // Booking modal (Calendly / SavvyCal placeholder)
  var overlay = document.getElementById("bookingModal");
  var openers = document.querySelectorAll("[data-open-booking]");
  var closers = document.querySelectorAll("[data-close-booking]");

  openers.forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (overlay) {
        overlay.classList.add("is-open");
        document.body.style.overflow = "hidden";
      }
    });
  });
  closers.forEach(function (btn) {
    btn.addEventListener("click", closeModal);
  });
  if (overlay) {
    overlay.addEventListener("click", function (e) {
      if (e.target === overlay) closeModal();
    });
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeModal();
  });
  function closeModal() {
    if (overlay) {
      overlay.classList.remove("is-open");
      document.body.style.overflow = "";
    }
  }

  // Duplicate marquee content for seamless infinite scroll
  document.querySelectorAll(".marquee-track").forEach(function (track) {
    track.innerHTML += track.innerHTML;
  });

  // Highlight active nav link based on current page
  var path = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a").forEach(function (a) {
    var href = a.getAttribute("href").split("#")[0];
    if (href === path || (href === "index.html" && path === "")) {
      a.classList.add("active");
    }
  });

  // Dual-Layer Parallax Scroll Effect for Hero Background (0.2x speed)
  var heroBg = document.querySelector(".hero-parallax-bg");
  var heroSec = document.querySelector(".hero");
  if (heroBg && heroSec) {
    var ticking = false;
    var speed = parseFloat(heroBg.getAttribute("data-speed")) || 0.2;

    function updateParallax() {
      var scrolled = window.pageYOffset || document.documentElement.scrollTop;
      var heroHeight = heroSec.offsetHeight;
      if (scrolled <= heroHeight + 200) {
        var bgOffset = scrolled * speed;
        heroBg.style.transform = "translate3d(0, " + bgOffset + "px, 0)";
      }
      ticking = false;
    }

    window.addEventListener("scroll", function () {
      if (!ticking) {
        window.requestAnimationFrame(updateParallax);
        ticking = true;
      }
    }, { passive: true });

    // Initial positioning
    updateParallax();
  }

  // Intersection Observer for Parallax Scroll Reveal Sections
  var revealSections = document.querySelectorAll(".split-reveal-section, .final-conversion-section");
  if (revealSections.length && "IntersectionObserver" in window) {
    var sectionObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-in-view");
        }
      });
    }, { threshold: 0.2 });
    revealSections.forEach(function (sec) {
      sectionObserver.observe(sec);
    });
  } else {
    revealSections.forEach(function (sec) {
      sec.classList.add("is-in-view");
    });
  }
});
